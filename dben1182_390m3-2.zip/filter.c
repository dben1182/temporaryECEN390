#include "filter.h"
#include "coef.h"
#include "queue.h"

// the number of IIR Filters, which corresponds to the
// number of z queues and output queues
#define NUM_IIR_FILTERS 10
#define NUM_Z_QUEUES NUM_IIR_FILTERS
#define NUM_OUTPUT_QUEUES NUM_IIR_FILTERS

// offsets for names and name lengths
#define ASCII_OFFSET 48
#define Z_QUEUE_NAME_LENGTH 10
#define Z_NAME_OFFSET 7
#define OUTPUT_QUEUE_NAME_LENGTH 15
#define OUTPUT_NAME_OFFSET 12

// the value we decimate by
#define DECIMATION_VALUE 10

// the sizes of our queues, or rather their lengths
#define X_QUEUE_SIZE 81
#define Y_QUEUE_SIZE 11
#define Z_QUEUE_SIZE 10
#define OUTPUT_QUEUE_SIZE 2000

// start values for for loops, indecies, and powers
#define FOR_LOOP_START_VALUE 0
#define INITIAL_QUEUE_VALUE 0
#define INITIAL_SUM_VALUE 0
#define INITIAL_POWER_VALUES 0

// offset used for index of last element of array
#define INDEX_OFFSET 1
// index of the oldest value in a queue
#define OLDEST_VALUE_INDEX 0

// delcaration of the xQueue, its size, and its name
static queue_t xQueue;
const static queue_size_t xQueue_size = X_QUEUE_SIZE;
const char xQueue_name[] = "xQueue";

// declaration of a yQueue, its size and name
static queue_t yQueue;
const static queue_size_t yQueue_size = Y_QUEUE_SIZE;
const char yQueue_name[] = "yQueue";

// declaration of the array of zQueues, their size, and name
const static queue_size_t zQueue_size = Z_QUEUE_SIZE;
static queue_t zQueues[NUM_Z_QUEUES];
char zQueueNames[Z_QUEUE_NAME_LENGTH] = "zQueue_";

// declaration of the array of output queues, their size, and name
const static queue_size_t outputQueue_size = OUTPUT_QUEUE_SIZE;
static queue_t outputQueues[NUM_OUTPUT_QUEUES];
char outputQueueNames[OUTPUT_QUEUE_NAME_LENGTH] = "outputQueue_";

// arrays used to store previous power values for use later in
// calculating power
double currentPowerValue[NUM_IIR_FILTERS];
double previousPowerValue[NUM_IIR_FILTERS];
double oldestValue[NUM_IIR_FILTERS];

// function that initializes arrays that store the power values that will
// be subtracted for the next iterations's calculation. Initializes them
// all to zero
void init_powerQueues();
void init_xQueue();
void init_yQueue();
void init_zQueues();
void init_outputQueues();

// function that initializes the xQueue function by calling the queue_init
// function and then pushing zeros to the entirety of the queue
void init_xQueue() {
  // calls initialization function
  queue_init(&xQueue, xQueue_size, xQueue_name);
  // iterates through each slot in the x_queue to fill it completely with zeros
  for (uint16_t i = FOR_LOOP_START_VALUE; i < xQueue_size; i++) {
    // calls queue overwrite function to fill with zeros
    queue_overwritePush(&xQueue, INITIAL_QUEUE_VALUE);
  }
}

// function that initializes the yQueue function by calling the queue_init
// function and then pushing zeros to the entirety of the queue
void init_yQueue() {
  // calls initialization function
  queue_init(&yQueue, yQueue_size, yQueue_name);
  // iterates through each slot in the y_queue to fill it completely with zeros
  for (uint16_t i = FOR_LOOP_START_VALUE; i < yQueue_size; i++) {
    // calls queue overwrite function to fill with zeros
    queue_overwritePush(&yQueue, INITIAL_QUEUE_VALUE);
  }
}

// function that initializes the zQueues by pushing zeros to the entirety of all
// ten z queues.
void init_zQueues() {
  // iterates through each of the ten seperate z queues and initialize each
  // of those respective slots to zeros
  for (uint16_t i = FOR_LOOP_START_VALUE; i < NUM_Z_QUEUES; i++) {
    // creates unique numbered name for z queues
    zQueueNames[Z_NAME_OFFSET] = i + ASCII_OFFSET;
    // calls initialization function
    queue_init(&(zQueues[i]), zQueue_size, zQueueNames);
    // fill each index with zeros
    for (uint16_t j = FOR_LOOP_START_VALUE; j < zQueue_size; j++) {
      // calls queue overwrite function to fill with zeros
      queue_overwritePush(&(zQueues[i]), INITIAL_QUEUE_VALUE);
    }
  }
}

// function that initializes the output queues by pushing zeros to
// all of the elements in each of the ten output queues
void init_outputQueues() {
  // iterates through each of the 10 output queues to initialize them
  for (uint16_t i = FOR_LOOP_START_VALUE; i < NUM_OUTPUT_QUEUES; i++) {
    // sets unique name for each output queue
    outputQueueNames[OUTPUT_NAME_OFFSET] = i + ASCII_OFFSET;
    // calls queue initialization function for each of the output queues
    queue_init(&(outputQueues[i]), outputQueue_size, outputQueueNames);
    // iterates through each spot and pushes zero onto the queue
    for (uint16_t j = FOR_LOOP_START_VALUE; j < outputQueue_size; j++) {
      // pushes zeros by calling helper function
      queue_overwritePush(&(outputQueues[i]), INITIAL_QUEUE_VALUE);
    }
  }
}

// function called at the start that initializes each of queues by calling
// their own respective initialization functions
void filter_init() {
  // initializes y queue
  init_yQueue();
  // initializes x queue
  init_xQueue();
  // initializes z queues
  init_zQueues();
  // initializes output queues
  init_outputQueues();
}

// Use this to copy an input into the input queue of the FIR-filter (xQueue).
void filter_addNewInput(double x) {
  // writes new number to x queue
  queue_overwritePush(&xQueue, x);
}

// fills queue with a specified value
void filter_fillQueue(queue_t *q, double fillValue) {
  // iterates through each slot in the queue and adds a filler value
  for (uint16_t i = FOR_LOOP_START_VALUE; i < queue_size(q); i++) {
    // pushes fill value
    queue_overwritePush(q, fillValue);
  }
}

// function that performs in code the actual FIR filtering, based on the
// FIR coefficients that we calculated in matlab and put in our coef.h file
double filter_firFilter() {
  // initializes sum for next value with zero
  double y_sum = INITIAL_SUM_VALUE;
  // iterates through each element in the x array, and convolves that array
  // with all 81 FIR coefficients, and takes their total sum
  for (uint16_t k = FOR_LOOP_START_VALUE; k < xQueue_size; k++) {
    // creates sum of the multiplication of the fir coefficients in forward
    // order multiplied with the xqueue elements in reverse order, and then
    // summed up
    y_sum = y_sum +
            firCoefficients[k] *
                queue_readElementAt(&xQueue, xQueue_size - INDEX_OFFSET - k);
  }
  // pushes that sum onto the y queue
  queue_overwritePush(&yQueue, y_sum);
  // returns that same sum
  return y_sum;
}

// function that is called to to bandpass filtering on a specified band for one
// of our ten signals

double filter_iirFilter(uint16_t filterNumber) {
  // two variables that will each be used as a sum
  double b_and_y_sum = INITIAL_SUM_VALUE;
  double a_and_z_sum = INITIAL_SUM_VALUE;
  // iterates through each value of the iir B coefficients and the Y queue and
  // convolves them
  for (uint16_t k = FOR_LOOP_START_VALUE; k < yQueue_size; k++) {
    // creates sum of the iir B coefficients in forward order and y queue
    // elements read in reverse order multiplied together and summed, which is
    // convolution
    b_and_y_sum =
        b_and_y_sum +
        (iirBCoefficientConstants[filterNumber][k]) *
            (queue_readElementAt(&yQueue, yQueue_size - INDEX_OFFSET - k));
  }
  // iterates through each value of the A coefficients and the Z elements and
  // convolves them
  for (uint16_t k = FOR_LOOP_START_VALUE; k < zQueue_size; k++) {
    // creates sum of the iir A coefficients in forward order and z queue
    // elements in reverse order which are convolved together
    a_and_z_sum =
        a_and_z_sum + iirACoefficientConstants[filterNumber][k] *
                          queue_readElementAt(&zQueues[filterNumber],
                                              zQueue_size - INDEX_OFFSET - k);
  }
  // then finds the b sum minus the a sum to get the next filter output
  double filter_sum = b_and_y_sum - a_and_z_sum;
  // pushes that sum onto the z queue and the output queue
  queue_overwritePush(&zQueues[filterNumber], filter_sum);
  queue_overwritePush(&outputQueues[filterNumber], filter_sum);
  // also returns that sum
  return filter_sum;
}

// function for computing the power of 2000 elements, or 200 milliseconds worth
// of information that has passed through the fir low pass filter, and then
// through one of our ten iir bandpass filters
double filter_computePower(uint16_t filterNumber, bool forceComputeFromScratch,
                           bool debugPrint) {
  // creates variable for the computed power
  double computedPower = INITIAL_SUM_VALUE;
  // case we are being forced to compute the power from scratch, which involves
  // taking the sum of the squares of each element in the output queue.
  // This is exremely computationally inefficient, so we only do it once, and
  // then do a marginal calculation each time
  if (forceComputeFromScratch) {
    // creates dummy variable to make the code cleaner
    double signalValue = INITIAL_SUM_VALUE;
    // iterates through all 2000 elements of our output queue
    for (uint16_t i = FOR_LOOP_START_VALUE; i < outputQueue_size; i++) {
      // sets dummy variable
      signalValue = queue_readElementAt(&outputQueues[filterNumber], i);
      // creates sum of the squares of the output values at those points
      computedPower = computedPower + signalValue * signalValue;
    }
  }
  // does the marginal calculation by subtracting power of oldest signal that
  // was just popped, or discarded from our output queue and adding the power of
  // our newest one to find the new computed power
  else {
    // variable for storing previous power value
    double previousPower = previousPowerValue[filterNumber];
    // variable for storing oldest value, or the one just popped
    double oldest = oldestValue[filterNumber];
    // gets newest element just added to the queue
    double newest = queue_readElementAt(&outputQueues[filterNumber],
                                        outputQueue_size - INDEX_OFFSET);
    // calculates newest computed value by taking the previous one, subtracting
    // the square of the most recently popped value and adding the square of the
    // newest value added
    computedPower = previousPower - (oldest * oldest) + (newest * newest);
  }
  // sets value for the specified filter to be the just computed power
  previousPowerValue[filterNumber] = computedPower;
  // also sets current power value to same computed power
  currentPowerValue[filterNumber] = computedPower;
  // sets oldest value to be the element at index zero, or the oldest index,
  // which will then be removed on the next iteration
  oldestValue[filterNumber] =
      queue_readElementAt(&outputQueues[filterNumber], OLDEST_VALUE_INDEX);
  // also returns the computed power
  return computedPower;
}

// gets the current power value of a specified output from a filter
double filter_getCurrentPowerValue(uint16_t filterNumber) {
  // returns from that currentpowervalue array
  return currentPowerValue[filterNumber];
}

// gets current power values for all the IIR filter outputs
// by putting them into an array, which we pass the address of into
void filter_getCurrentPowerValues(double powerValues[]) {
  // iterates through all ten IIR filters and sets the power value
  for (uint16_t i = FOR_LOOP_START_VALUE; i < NUM_IIR_FILTERS; i++) {
    // sets value
    powerValues[i] = currentPowerValue[i];
  }
}

// function to get the normalized power values for all ten IIR filters
void filter_getNormalizedPowerValues(double normalizedArray[],
                                     uint16_t *indexOfMaxValue) {
  double maxValue = INITIAL_SUM_VALUE;
  // iterates through all ten of the IIR filters to find largest number there
  for (uint16_t i = FOR_LOOP_START_VALUE; i < NUM_IIR_FILTERS; i++) {
    // checks to see if it can find a value that is bigger than any previously
    // found
    if (currentPowerValue[i] > maxValue) {
      // gets its value and index
      maxValue = currentPowerValue[i];
      *indexOfMaxValue = i;
    }
  }
  // iterates through all ten IIR filters and divides them by the max
  // power found to get a relative calculation
  for (uint16_t i = FOR_LOOP_START_VALUE; i < NUM_IIR_FILTERS; i++) {
    // doed the dividing
    normalizedArray[i] = (currentPowerValue[i] / maxValue);
  }
}

// returns the address of the fir coefficient array, found
// in its own h file
const double *filter_getFirCoefficientArray() { return firCoefficients; }

// returns the number of FIR coefficients
uint32_t filter_getFirCoefficientCount() { return FIR_FILTER_TAP_COUNT; }

// returns address of the iir A coefficient Array
const double *filter_getIirACoefficientArray(uint16_t filterNumber) {
  return iirACoefficientConstants[filterNumber];
}

// returns number of IIR A coefficients
uint32_t filter_getIirACoefficientCount() { return IIR_A_COEFFICIENT_COUNT; }

// returns address of the iir B coefficient Array
const double *filter_getIirBCoefficientArray(uint16_t filterNumber) {
  return iirBCoefficientConstants[filterNumber];
}

// returns number of IIR B coefficients
uint32_t filter_getIirBCoefficientCount() { return IIR_B_COEFFICIENT_COUNT; }

// returns the size of the Y queue
uint32_t filter_getYQueueSize() { return yQueue_size; }

// returns value we are decimating by
uint16_t filter_getDecimationValue() { return DECIMATION_VALUE; }

// returns the address of the xQueue
queue_t *filter_getXQueue() { return &xQueue; }

// returns address of the yQueue
queue_t *filter_getYQueue() { return &yQueue; }

// returns the address of a zQueue at a specified index
queue_t *filter_getZQueue(uint16_t filterNumber) {
  return &zQueues[filterNumber];
}

// returns the address of an IIR Output queue at a specified index
queue_t *filter_getIirOutputQueue(uint16_t filterNumber) {
  return &outputQueues[filterNumber];
}

// function that initializes arrays that store the power values that will
// be subtracted for the next iterations's calculation. Initializes them
// all to zero
void init_powerQueues() {
  // for loop that iterates and corresponds to each output queue for
  // each IIR Filter
  for (uint16_t i = FOR_LOOP_START_VALUE; i < NUM_IIR_FILTERS; i++) {
    previousPowerValue[i] = INITIAL_POWER_VALUES;
    currentPowerValue[i] = INITIAL_POWER_VALUES;
    oldestValue[i] = INITIAL_POWER_VALUES;
  }
}